package com.cigna.sees.force.test.emr.serverless;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestEmrServerlessApplicationTests {

	@Test
	void contextLoads() {
	}

}
