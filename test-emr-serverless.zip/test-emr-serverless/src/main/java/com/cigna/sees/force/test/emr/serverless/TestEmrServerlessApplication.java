package com.cigna.sees.force.test.emr.serverless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestEmrServerlessApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestEmrServerlessApplication.class, args);
	}

}
